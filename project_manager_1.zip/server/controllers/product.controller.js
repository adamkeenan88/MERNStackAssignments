const Product = require("../models/product.model");

module.exports.index = (req, res) => {
  res.json({ message: "Hello World" });
};

module.exports.createProduct = (request, response) => {
  const { title, price, description } = request.body;
  Product.create({
    title,
    price,
    description,
  })
    .then((product) => response.json(product))
    .catch((err) => response.json(err));
};
module.exports.findProduct = (req, res) => {
  Product.find()
    .then((allProducts) => res.json({ product: allProducts }))
    .catch((err) => res.json({ message: "Something went wrong", error: err }));
};

// module.exports.findOneJoke = (req, res) => {
//   Jokes.findOne({ _id: req.params.jokeid })
//     .then((oneJoke) => res.json({ joke: oneJoke }))
//     .catch((err) => res.json({ message: "Something went wrong", error: err }));
// };

// module.exports.createNewJoke = (req, res) => {
//   Jokes.create(req.body)
//     .then((newlyCreatedJoke) => res.json({ joke: newlyCreatedJoke }))
//     .catch((err) => res.json({ message: "Something went wrong", error: err }));
// };

// module.exports.updateOneJoke = (req, res) => {
//   Jokes.findOneAndUpdate({ _id: req.params.jokeid }, req.body, { new: true })
//     .then((updatedJoke) => res.json({ joke: updatedJoke }))
//     .catch((err) => res.json({ message: "Something went wrong", error: err }));
// };

// module.exports.deleteAnExistingJoke = (req, res) => {
//   Jokes.deleteOne({ _id: req.params.jokeid })
//     .then((result) => res.json({ result: result }))
//     .catch((err) => res.json({ message: "Something went wrong", error: err }));
// };
