const ProductController = require("../controllers/product.controller");

module.exports = (app) => {
  app.get("/api", ProductController.index);
  app.get("/healthcheck", (req, res) => {
    res.send("Everything ok");
  });
  app.post("/api/product", ProductController.createProduct);
  // app.post("/api/jokes/", JokesController.createNewJoke);
  app.get("/api/product", ProductController.findProduct);
  // app.put("/api/jokes/:jokeid", JokesController.updateOneJoke);
  // app.delete("/api/jokes/:jokeid", JokesController.deleteAnExistingJoke);
};
