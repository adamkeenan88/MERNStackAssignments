import React from "react";
import ProductForm from "./Components/ProductForm";
import "./App.css";

function App() {
  return (
    <div className="App">
      <ProductForm />
    </div>
  );
}
export default App;
