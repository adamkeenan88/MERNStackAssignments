const DisplayInt = (props) => {
  if (isNaN(props.int)) {
    return <h1>The word is: {props.int}</h1>;
  } else return <h1>The number is: {props.int}</h1>;
};

export default DisplayInt;
