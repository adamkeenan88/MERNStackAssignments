import "./App.css";
import { useEffect, useState } from "react";

function App() {
  const [pokemon, setPokemon] = useState([]);

  useEffect(() => {
    console.log("hello");
    fetch("https://pokeapi.co/api/v2/pokemon?limit=2000")
      .then((response) => response.json())
      .then((response) => setPokemon(response.results));
  }, []);
  return (
    <div className="App">
      {pokemon.length > 0 &&
        pokemon.map((pokemon, index) => {
          return <div key={index}>{pokemon.name}</div>;
        })}
      ;
    </div>
  );
}

export default App;
