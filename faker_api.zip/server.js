const express = require("express");
const app = express();
const faker = require("faker");

const createUser = () => {
  const newUser = {
    _id: faker.datatype.uuid(),
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    phone: faker.phone.phoneNumber(),
    email: faker.internet.email(),
    password: faker.internet.password(),
  };
  return newUser;
};

const createCompany = () => {
  const newCompany = {
    _id: faker.datatype.uuid(),
    name: faker.company.companyName(),
    streetAddress: faker.address.streetName(),
    city: faker.address.city(),
    state: faker.address.state(),
    zipCode: faker.address.zipCodeByState(),
    country: faker.address.country(),
  };
  return newCompany;
};

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/api", (req, res) => {
  res.json({ message: "Now broadcasting!" });
});

app.get("/api/users/new", (req, res) => {
  const newCreatedUser = createUser();
  res.json(newCreatedUser);
});
app.get("/api/companies/new", (req, res) => {
  const newCreatedCompany = createCompany();
  res.json(newCreatedCompany);
});
app.get("/api/user/company", (req, res) => {
  const newCreatedUser = createUser();
  const newCreatedCompany = createCompany();
  res.json({ newCreatedUser, newCreatedCompany });
});
const server = app.listen(8000, () =>
  console.log(`Server is locked and loaded on port ${server.address().port}!`)
);
