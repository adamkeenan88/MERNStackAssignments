const JokesController = require("../controllers/jokes.controller");

module.exports = (app) => {
  app.get("/api/jokes/", JokesController.findAllJokes);
  app.post("/api/jokes/", JokesController.createNewJoke);
  app.get("/api/jokes/:jokeid", JokesController.findOneJoke);
  app.put("/api/jokes/:jokeid", JokesController.updateOneJoke);
  app.delete("/api/jokes/:jokeid", JokesController.deleteAnExistingJoke);
};
