import logo from './logo.svg';
import './App.css';
import {useState} from 'react';

function App() {
    const [firstname, setFirstname] = useState("");
    const [lastname, setLastname] = useState("");
    const [emailaddress, setEmailaddress] = useState("");
    const [password, setPassword] = useState("");
    const [confirmpass, setConfirmpass] = useState("");

    return(
      <div className="App">
        <form action="" >
          <div>
            First Name: {" "}
            <input type="text" onChange={ (e) => setFirstname(e.target.value)} />
            {firstname.length > 2 ? null : firstname.length >=1 ? (<p>'First Name must be at least 2 characters'</p>) : null}
          </div>
          <div>
            Last Name: {" "}
            <input type="text" onChange={ (e) => setLastname(e.target.value)} />
            {lastname.length > 2 ? null : lastname.length >=1 ? (<p>'Last Name must be at least 2 characters'</p>) : null}
          </div>
          <div>
            Email Address: {" "}
            <input type="text" onChange={ (e) => setEmailaddress(e.target.value)} />
            {emailaddress.length > 2 ? null : emailaddress.length >=1 ? (<p>'Email must be at least 2 characters'</p>) : null}
          </div>
          <div>
            Password: {" "}
            <input type="text" onChange={ (e) => setPassword(e.target.value)} />
            {password.length > 8 ? null : password.length >=1 ? (<p>'Password must be at least 8 characters'</p>) : null}
          </div>
          <div>
            Confirm Password: {" "}
            <input type="text" onChange={ (e) => setConfirmpass(e.target.value)} />
            {confirmpass !== password ? (<p>'Passwords must match'</p>) : null}
          </div>
            <input type="submit" value="Create User" />
        </form>
    </div>
  );
};

export default App;
